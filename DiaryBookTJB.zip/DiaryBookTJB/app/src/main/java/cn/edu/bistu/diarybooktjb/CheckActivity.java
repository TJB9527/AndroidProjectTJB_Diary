package cn.edu.bistu.diarybooktjb;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class CheckActivity extends AppCompatActivity implements View.OnClickListener{
    private TextView title,content,time,author;
    private Button editBtn,deleteBtn;
    private Intent intentchk;
    private ImageView imageView;
    private String imgName;//获得当前记录的图片名字
    private Bitmap bitmap;//获得当前记录的图片的Bitmap对象

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check);

        editBtn = findViewById(R.id.editBtn);
        deleteBtn = findViewById(R.id.deleteBtn);

        title = findViewById(R.id.chktitle);
        content = findViewById(R.id.chkcontent);
        time = findViewById(R.id.chktime);
        author = findViewById(R.id.chkauthor);

        imageView = findViewById(R.id.imageView);

        //通过intent显示日记内容
        intentchk = getIntent();;//获得前面活动传递的intent对象
        title.setText(intentchk.getStringExtra("title"));
        content.setText(intentchk.getStringExtra("content"));
        time.setText(intentchk.getStringExtra("time"));
        author.setText(intentchk.getStringExtra("author"));

        imgName = intentchk.getStringExtra("imgName");
        System.out.println("++++++++++++++++输出imagName："+imgName);
        if(imgName!=null){
            bitmap = BitmapFactory.decodeFile(getFilesDir().getAbsolutePath()+"/"+imgName);//重要
            System.out.println("************************************"+getFilesDir().getAbsolutePath()+"/"+imgName);
            imageView.setImageBitmap(bitmap);//在查看页面显示主页传递的图片
        }

        editBtn.setOnClickListener(this);
        deleteBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.editBtn:
                Intent intentEdit = new Intent(CheckActivity.this,EditActivity.class);
                intentEdit.putExtra("id",getIntent().getStringExtra("id"));
                intentEdit.putExtra("title",title.getText().toString());
                intentEdit.putExtra("content",content.getText().toString());
                intentEdit.putExtra("time",time.getText().toString());
                intentEdit.putExtra("author",author.getText().toString());
                if(imgName!=null){
                    intentEdit.putExtra("imgName",imgName.toString());
                }
                startActivityForResult(intentEdit,3);
                break;
            case R.id.deleteBtn:
                REAL_DELETE();
                setResult(RESULT_OK);
                break;
            default:
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case 3:
                if(data!=null){
                    title.setText(data.getStringExtra("title"));
                    content.setText(data.getStringExtra("content"));
                    time.setText(data.getStringExtra("time"));
                    author.setText(data.getStringExtra("author"));

                    imgName = data.getStringExtra("imgName");
                    bitmap = BitmapFactory.decodeFile(getFilesDir().getAbsolutePath()+"/"+imgName);
                    imageView.setImageBitmap(bitmap);

                    setResult(RESULT_OK,data);
                }
                break;
            default:
                break;
        }
    }

    void REAL_DELETE(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);//交互式提醒(二选一)
        builder.setMessage("确定要删除这条日记吗？");
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                MyDatabase db = new MyDatabase(CheckActivity.this);
                db.deleteDiary(getIntent().getStringExtra("id"));
                finish();
            }
        });
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.show();

    }
}