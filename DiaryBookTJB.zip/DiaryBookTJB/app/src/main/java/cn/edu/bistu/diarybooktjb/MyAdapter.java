package cn.edu.bistu.diarybooktjb;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class MyAdapter extends BaseAdapter {
    private Activity ac;
    private LayoutInflater mInflater;// 动态布局映射
    private List<HashMap<String, Object>> mData = new ArrayList<>();
    private MyDatabase db;

    public MyAdapter(Context context) {
        this.mInflater = LayoutInflater.from(context);
    }

    public MyAdapter(Context context,Activity ac) {
        this.ac  = ac;
        this.mInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        mData = getData();
        return mData.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    static class ViewHolder{
        public TextView ID,Title,Content,Time,Author;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder = new ViewHolder();
        if(view==null){
            view = mInflater.inflate(R.layout.activity_holder_view,null);
            holder.Title = (TextView) view.findViewById(R.id.button_Title);
            holder.Time = (TextView) view.findViewById(R.id.button_CreateTime);
            holder.Content = (TextView)view.findViewById(R.id.button_Content);
            holder.Author = (TextView) view.findViewById(R.id.button_Author);
            view.setTag(holder);
        }else{
            holder = (ViewHolder) view.getTag();
        }
        holder.Title.setText(mData.get(i).get("title").toString());
        holder.Content.setText(mData.get(i).get("content").toString());
        holder.Time.setText(mData.get(i).get("time").toString());
        holder.Author.setText(mData.get(i).get("author").toString());
        return view;
    }

    // 初始化一个List
    public List<HashMap<String, Object>> getData() {
        // 新建一个集合类，用于存放多条数据
        ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();
        db = new MyDatabase(ac);
        Cursor cursor = null;

        if(MainActivity.signal==1){
            if(!(MainActivity.regularQuerySub.equals(""))){
                cursor = db.regularQuery(MainActivity.regularQuerySub);//正则匹配
            }
            else
                MainActivity.signal=0;
        }
        if(MainActivity.signal!=1){
            cursor = db.readAllData("");//读取所有数据
        }
        if(cursor.getCount()==0){
            Toast.makeText(ac,"The database is null without data.",Toast.LENGTH_SHORT).show();
        }else {
            while(cursor.moveToNext()){
                HashMap<String, Object> map = new HashMap<>();
                map.put("id",cursor.getString(0));
                map.put("title",cursor.getString(1));
                map.put("content",cursor.getString(2));
                map.put("time",cursor.getString(3));
                map.put("author",cursor.getString(4));
                map.put("imgName",cursor.getString(5));
                list.add(map);
            }
        }
        return list;
    }
}
