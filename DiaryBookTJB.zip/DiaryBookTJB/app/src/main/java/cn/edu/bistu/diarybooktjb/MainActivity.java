package cn.edu.bistu.diarybooktjb;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ListView listView;
    private Button addBtn,userBtn;
    private List<HashMap<String, Object>> mData = new ArrayList<>();
    private MyAdapter myAdapter;
    public static int signal = 0;
    public static String regularQuerySub = "";  //正则匹配查询字符串

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addBtn = findViewById(R.id.AddBtn);
        userBtn = findViewById(R.id.UserBtn);

        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentAdd = new Intent(MainActivity.this,AddActivity.class);
                startActivityForResult(intentAdd,1);
            }
        });

        userBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intentUser = new Intent(MainActivity.this,UserActivity.class);
                startActivity(intentUser);
            }
        });

        //通过Adapter适配器将数据库中数据传至listview显示
        listView = findViewById(R.id.lv);
        myAdapter = new MyAdapter(this,this);
        listView.setAdapter(myAdapter);

        //列表项监听事件
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intentChk = new Intent(MainActivity.this,CheckActivity.class);
                //获得当前列表项对应数据库中的数据
                mData = myAdapter.getData();
                intentChk.putExtra("id",mData.get(i).get("id").toString());
                intentChk.putExtra("title",mData.get(i).get("title").toString());
                intentChk.putExtra("content",mData.get(i).get("content").toString());
                intentChk.putExtra("time",mData.get(i).get("time").toString());
                intentChk.putExtra("author",mData.get(i).get("author").toString());
                if(mData.get(i).get("imgName")!=null){
                    intentChk.putExtra("imgName",mData.get(i).get("imgName").toString());
                }
                startActivityForResult(intentChk,2);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
            case 1:
                if(resultCode==RESULT_OK){
                    recreate();
                }
                break;
            case 2:
                if(resultCode==RESULT_OK) recreate();
                break;
            default:
                break;
        }
    }

    /**
     * 加载主界面顶部菜单栏搜索按钮，实现基于数据库的对listview页面的正则匹配查询
     * @param menu
     * @return
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.search, menu);
        MenuItem item = menu.findItem(R.id.Menu_Search1);
        SearchView searchView = (SearchView) item.getActionView();
        if (searchView.equals(null)) {

        }else {
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    return false;
                }
                @Override
                public boolean onQueryTextChange(String newText) {
                    signal = 1;
                    regularQuerySub = newText;
                    myAdapter.notifyDataSetChanged();
                    listView.setAdapter(myAdapter);
                    return false;
                }
            });
        }

        return super.onCreateOptionsMenu(menu);
    }
}