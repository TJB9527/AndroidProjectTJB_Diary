package cn.edu.bistu.diarybooktjb;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.text.SimpleDateFormat;
import java.util.Date;

public class MyDatabase extends SQLiteOpenHelper {
    private Context context;
    private static final String DATABASE_NAME = "TJBDiaryBook.db";
    private static final int DATABASE_VERSION = 1;
    private static String TABLE_NAME = "DiaryBook";
    private static String COLUMN_ID = "TheID";
    private static String COLUMN_TITLE = "TheTitle";
    private static String COLUMN_CONTENT = "TheContent";
    private static String COLUMN_CREATETIME = "TheCreateTime";
    private static String COLUMN_AUTHOR = "TheAuthor";
    private static String COLUMN_IMG = "TheImgName";



    //构造方法
    public MyDatabase(@Nullable Context context) {
        super(context, DATABASE_NAME,null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE "+TABLE_NAME+" ("+
                COLUMN_ID+" INTEGER PRIMARY KEY AUTOINCREMENT,"+
                COLUMN_TITLE+" TEXT,"+
                COLUMN_CONTENT+" TEXT,"+
                COLUMN_CREATETIME+" TEXT,"+
                COLUMN_AUTHOR+" TEXT,"+
                COLUMN_IMG+" TEXT);";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    /**
     * query
     * @return
     */
    Cursor readAllData(){
        String sql = "SELECT * FROM "+TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if(db!=null){
            cursor = db.rawQuery(sql,null);
        }
        return cursor;
    }

    /**
     * insert
     * @param title
     * @param content
     * @param time
     * @param author
     * @param imgName
     */
    public void addDiary(String title,String content,String time,String author,String imgName){
        SQLiteDatabase db = this. getWritableDatabase();//db为可写入对象
        ContentValues cv =new ContentValues();//一条记录
        cv.put(COLUMN_TITLE,title);
        cv.put(COLUMN_CONTENT,content);
        cv.put(COLUMN_CREATETIME,time);
        cv.put(COLUMN_AUTHOR,author);
        cv.put(COLUMN_IMG,imgName);
        long result = db.insert(TABLE_NAME,null,cv);
        if(result==-1){
            Toast.makeText(context,"add error!",Toast.LENGTH_SHORT).show();
        }
        else
            Toast.makeText(context,"add successful!",Toast.LENGTH_SHORT).show();
    }

    /**
     * delete
     * @param id
     */
    public void deleteDiary(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete("DiaryBook"," TheID=?",new String[]{id});
        if(result==-1){
            Toast.makeText(context,"delete error!",Toast.LENGTH_SHORT).show();
        }
        else
            Toast.makeText(context,"delete successful!",Toast.LENGTH_SHORT).show();
    }

    /**
     * update
     * @param id
     * @param title
     * @param content
     * @param time
     * @param author
     */
    public void updateDiary(String id,String title,String content,String time,String author,String imgName){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_ID,id);
        cv.put(COLUMN_TITLE,title);
        cv.put(COLUMN_CONTENT,content);
        cv.put(COLUMN_CREATETIME,time);
        cv.put(COLUMN_AUTHOR,author);
        cv.put(COLUMN_IMG,imgName);
        int result = db.update("DiaryBook",cv,"TheID=?",new String[]{id});
        if(result==-1){
            Toast.makeText(context,"update error!",Toast.LENGTH_SHORT).show();//为什么用context?

        }else
            Toast.makeText(context,"update successful!",Toast.LENGTH_SHORT).show();
    }

    /**
     * 正则匹配查询
     */
    Cursor regularQuery(String sub){
        Cursor cursor = null;
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_ID,COLUMN_TITLE,COLUMN_CONTENT,COLUMN_CREATETIME,COLUMN_AUTHOR,COLUMN_IMG};
        String selections = COLUMN_TITLE+" like '%"+sub+"%'";
        cursor = db.query("DiaryBook",columns,selections,null,null,null,null);
        return cursor;
    }

}
