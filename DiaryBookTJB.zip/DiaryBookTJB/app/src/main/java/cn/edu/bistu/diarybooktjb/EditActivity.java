package cn.edu.bistu.diarybooktjb;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class EditActivity extends AppCompatActivity implements View.OnClickListener{
    private EditText edtitle,edcontent;
    private TextView edtime,edauthor;
    private Button sureBtn,resetBtn;
    private Intent intent;
    private ImageView imageView,editImgBtn;
    private String imgName;  //原照片名
    private Bitmap bitmap;
    private String imgNameEdit = "";//更新后的照片名

    //图片
    private static final int TAKE_PICTURE = 0;  //拍照
    private static final int CHOOSE_PICTURE = 1;  //从相册中选择照片
    private static final int SCALE = 5;//照片缩小比例
    private File mImageFile;
    private Uri mImageUri;
    private String mImagePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        edtitle = findViewById(R.id.edtitle);
        edcontent = findViewById(R.id.edcontent);
        edtime = findViewById(R.id.edtime);
        edauthor = findViewById(R.id.edauthor);

        sureBtn = findViewById(R.id.sureBtn);
        resetBtn = findViewById(R.id.resetBtn);
        imageView = findViewById(R.id.imageView);
        editImgBtn = findViewById(R.id.editImageBtn);

        sureBtn.setOnClickListener(this);
        resetBtn.setOnClickListener(this);
        editImgBtn.setOnClickListener(this);

        intent = getIntent();
        edtitle.setText(intent.getStringExtra("title"));
        edcontent.setText(intent.getStringExtra("content"));
        edtime.setText(intent.getStringExtra("time"));
        edauthor.setText(intent.getStringExtra("author"));

        imgName = intent.getStringExtra("imgName");
        bitmap = BitmapFactory.decodeFile(getFilesDir().getAbsolutePath()+"/"+imgName);
        imageView.setImageBitmap(bitmap);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.sureBtn:
                MyDatabase db = new MyDatabase(EditActivity.this);

                String id = getIntent().getStringExtra("id");
                String title = edtitle.getText().toString();
                String content = edcontent.getText().toString();
                String author = edauthor.getText().toString();
                SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss ");//创建时间-格式化
                String time = sf.format(new Date());

                if(imgNameEdit=="")
                    db.updateDiary(id,title,content,time,author,imgName);
                else
                    db.updateDiary(id,title,content,time,author,imgNameEdit);

                Intent intentBackToCHK = new Intent();
                intentBackToCHK.putExtra("title",title);
                intentBackToCHK.putExtra("content",content);
                intentBackToCHK.putExtra("time",time);
                intentBackToCHK.putExtra("author",author);
                if(imgNameEdit=="")
                    intentBackToCHK.putExtra("imgName",imgName);
                else
                    intentBackToCHK.putExtra("imgName",imgNameEdit);

                setResult(RESULT_OK,intentBackToCHK);
                finish();
                break;
            case R.id.editImageBtn:
                showPicturePicker(EditActivity.this);
                break;
            case R.id.resetBtn:
                reset();
                break;
            default:
                break;
        }
    }

    /**
     * 重置
     */
    public void reset(){
        intent = getIntent();
        edtitle.setText(intent.getStringExtra("title"));
        edcontent.setText(intent.getStringExtra("content"));
        edtime.setText(intent.getStringExtra("time"));
        edauthor.setText(intent.getStringExtra("author"));
        imageView.setImageBitmap(bitmap);
    }

    /**
     * 调用系统相机和相册获取图片
     * @param context
     */
    public void showPicturePicker(Context context){
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        //设置弹出框标题
        builder.setTitle("请选择");
        builder.setNegativeButton("取消", null);
        builder.setItems(new String[]{"相机","相册"}, new DialogInterface.OnClickListener() {
            //类型码
            int REQUEST_CODE;
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case TAKE_PICTURE:
                        startCamera();
                        break;
                    case CHOOSE_PICTURE:
                        //发送打开相册程序器请求
                        Intent openAlbumIntent = new Intent(Intent.ACTION_GET_CONTENT);
                        REQUEST_CODE = CHOOSE_PICTURE;
                        openAlbumIntent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
                        startActivityForResult(openAlbumIntent, REQUEST_CODE);
                        break;
                    default:
                        break;
                }
            }
        });
        builder.create().show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case TAKE_PICTURE:
                    //将保存在本地的图片取出并缩小后显示在界面上
                    Bitmap cameraBitmap = BitmapFactory.decodeFile(mImagePath);
                    System.out.println("**********************"+mImagePath);
                    Bitmap Bitmap_CAMERA = ImageTools.zoomBitmap(cameraBitmap, cameraBitmap.getWidth() / SCALE, cameraBitmap.getHeight() / SCALE);
                    //由于Bitmap内存占用较大，这里需要回收内存，否则会报out of memory异常
                    cameraBitmap.recycle();

                    //将处理过的图片显示在界面上，并保存到本地
                    imageView.setImageBitmap(Bitmap_CAMERA);
                    String s=String.valueOf(System.currentTimeMillis());
                    imgName = imgNameEdit;
                    break;
                case CHOOSE_PICTURE:
                    ContentResolver resolver = getContentResolver();
                    //照片的原始资源地址
                    Uri originalUri = data.getData();
                    try {
                        //使用ContentProvider通过URI获取原始图片
                        Bitmap photoBitmap = MediaStore.Images.Media.getBitmap(resolver, originalUri);
                        if (photoBitmap != null) {
                            //为防止原始图片过大导致内存溢出，这里先缩小原图显示，然后释放原始Bitmap占用的内存
                            Bitmap Bitmap_ALBUM = ImageTools.zoomBitmap(photoBitmap, photoBitmap.getWidth() / SCALE, photoBitmap.getHeight() / SCALE);
                            //释放原始图片占用的内存，防止out of memory异常发生
                            photoBitmap.recycle();

                            //将处理过的图片显示在界面上，并保存到本地
                            imageView.setImageBitmap(Bitmap_ALBUM);
                            String s1=String.valueOf(System.currentTimeMillis());
                            ImageTools.savePhotoToSDCard(Bitmap_ALBUM,getFilesDir().getAbsolutePath(), s1);
                            imgNameEdit=s1+".png";
                        }
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * 启动相机
     */
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private void startCamera() {
        Intent intent = new Intent();
        //指定动作，启动相机
        intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.addCategory(Intent.CATEGORY_DEFAULT);
        //创建文件
        createImageFile();
        //添加权限
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        //获取uri
        mImageUri = FileProvider.getUriForFile(this, "cn.edu.bistu.diarybooktjb.provider", mImageFile);
        System.out.println("**********************2"+mImageUri);
        //将uri加入到额外数据
        intent.putExtra(MediaStore.EXTRA_OUTPUT, mImageUri);
        //启动相机并要求返回结果
        startActivityForResult(intent, TAKE_PICTURE);
    }

    /**
     * 调用系统相机时创建图片文件，文件直接定位到应用程序内部存储器
     */
    private void createImageFile(){
        //设置图片文件名（含后缀），以当前时间的毫秒值为名称
        imgNameEdit = Calendar.getInstance().getTimeInMillis() + ".jpg";

        //创建图片文件--getFilesDir().getAbsolutePath()直接定位到内部存储（data下file文件夹）
        mImageFile = new File(getFilesDir().getAbsolutePath()+"/", imgNameEdit);
        /*看file方法*/

        //将图片的绝对路径设置给mImagePath，后面会用到
        mImagePath = mImageFile.getAbsolutePath();
        System.out.println("**********************1"+mImagePath);
        //按设置好的目录层级创建
        mImageFile.getParentFile().mkdirs();
        //不加这句会报Read-only警告。且无法写入SD
        mImageFile.setWritable(true);
    }

}