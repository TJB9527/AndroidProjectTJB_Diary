package cn.edu.bistu.diarybooktjb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;

public class UserActivity extends AppCompatActivity implements View.OnClickListener{
    private Button saveData,restoreData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        saveData = (Button) findViewById(R.id.save_data);
        restoreData = (Button) findViewById(R.id.restore_data);
        saveData.setOnClickListener(this);
        restoreData.setOnClickListener(this);
    }
    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.save_data:
                saveData();
                break;
            case R.id.restore_data:
                restoreData();
                break;
        }
    }

    /**
     * 保存数据
     */
    private void saveData(){
        SharedPreferences.Editor editor = getSharedPreferences("data", MODE_PRIVATE).edit();
        //获取姓名
        EditText name = (EditText) findViewById(R.id.name);
        editor.putString("name", name.getText().toString());
        //获取年龄
        EditText age = (EditText) findViewById(R.id.age);
        if(TextUtils.isEmpty(age.getText().toString()))
            editor.putInt("age", 0);
        else
            editor.putInt("age", Integer.parseInt(age.getText().toString()));
        //获取性别
        RadioGroup gender = (RadioGroup)findViewById(R.id.gender);
        if(gender.getCheckedRadioButtonId()==R.id.radiomale)
            editor.putBoolean("male", true);
        else
            editor.putBoolean("male", false);
        editor.commit();
    }

    /**
     * 读取数据
     */
    private void restoreData(){
        SharedPreferences prefs = getSharedPreferences("data", MODE_PRIVATE);
        //获取姓名
        String name = prefs.getString("name", "");
        //获取年龄
        int age = prefs.getInt("age",0);
        //获取性别
        boolean genderChoice = prefs.getBoolean("male", false);

        EditText nameText = (EditText)findViewById(R.id.name);
        nameText.setText(name);

        EditText ageText = (EditText)findViewById(R.id.age);
        ageText.setText(String.valueOf(age));

        RadioGroup gender = (RadioGroup)findViewById(R.id.gender);
        if(genderChoice)
            gender.check(R.id.radiomale);
        else
            gender.check(R.id.radiofemale);
    }

}