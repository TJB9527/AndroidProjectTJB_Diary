package cn.edu.bistu.diarybooktjb;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.io.IOException;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;

public class AddActivity extends AppCompatActivity implements View.OnClickListener {
    private static final int TAKE_PHOTO_REQUEST_ONE = 0;
    private EditText title,content;
    private TextView author;
    private Button addButton,returnBtn;
    private ImageView imageView,addImageBtn;
    private String authorShared;
    private final int RC_CAMERA = 1;
    private final int RC_ALBUM = 2;
    private Uri imageUri1,imageUri2;
    private Bitmap imgBitmap;
    private  String imgName="";   //图片名

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        title = findViewById(R.id.title);
        content = findViewById(R.id.content);
        author = findViewById(R.id.author);

        addButton = findViewById(R.id.AddBtn);
        returnBtn = findViewById(R.id.ReturnBtn);
        addImageBtn = findViewById(R.id.addImageBtn);
        imageView = findViewById(R.id.imageView);

        addButton.setOnClickListener(this);
        returnBtn.setOnClickListener(this);
        addImageBtn.setOnClickListener(this);

        //读取SharedPreferences中的作者信息，用于新建日记的“作者”字段的值，无则返回默认值
        SharedPreferences getter = getSharedPreferences("data",MODE_PRIVATE);
        authorShared = getter.getString("name","寻真");
        if(authorShared.equals("")){
            authorShared = "寻真";
        }
        author.setText(authorShared);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.AddBtn:
                SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss ");//创建时间-格式化
                String datetime = sf.format(new Date());

                MyDatabase db = new MyDatabase(this);

                System.out.println("------"+title.getText().toString());
                if("".equals(title.getText().toString())){
                    Toast.makeText(AddActivity.this,"标题不能为空",Toast.LENGTH_SHORT).show();
                    break;
                }
                //向数据库添加记录
                db.addDiary(title.getText().toString().trim(),
                        content.getText().toString().trim(),
                        datetime,
                        authorShared,
                        imgName);

                Intent intentBack = new Intent();
                intentBack.putExtra("title",title.getText().toString());
                intentBack.putExtra("content",content.getText().toString());
                intentBack.putExtra("time",datetime);
                intentBack.putExtra("author",authorShared);
                setResult(RESULT_OK,intentBack);
                finish();
                break;
            case R.id.ReturnBtn:
                finish();//销毁当前Activity
                break;
            case R.id.addImageBtn:
                showPicturePicker(AddActivity.this);
                break;
            default:
                break;
        }
    }

    //图片
    private static final int TAKE_PICTURE = 0;  //拍照
    private static final int CHOOSE_PICTURE = 1;  //从相册中选择照片
    private static final int SCALE = 5;//照片缩小比例
    private String mImageName = null;
    private File mImageFile;
    private Uri mImageUri;
    private String mImagePath;

    /**
     * 调用系统相机和相册获取图片
     * @param context
     */
    public void showPicturePicker(Context context){
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        //设置弹出框标题
        builder.setTitle("请选择");
        builder.setNegativeButton("取消", null);
        builder.setItems(new String[]{"相机","相册"}, new DialogInterface.OnClickListener() {
            //类型码
            int REQUEST_CODE;
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case TAKE_PICTURE:
                        startCamera();
                        break;
                    case CHOOSE_PICTURE:
                        //发送打开相册程序器请求
                        Intent openAlbumIntent = new Intent(Intent.ACTION_GET_CONTENT);
                        REQUEST_CODE = CHOOSE_PICTURE;
                        openAlbumIntent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
                        startActivityForResult(openAlbumIntent, REQUEST_CODE);
                        break;
                    default:
                        break;
                }
            }
        });
        builder.create().show();
    }


    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private void startCamera() {
        Intent intent = new Intent();
        //指定动作，启动相机
        intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.addCategory(Intent.CATEGORY_DEFAULT);//
        //创建文件
        createImageFile();
        //添加权限
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        //获取uri
        mImageUri = FileProvider.getUriForFile(this, "cn.edu.bistu.diarybooktjb.provider", mImageFile);
        System.out.println("**********************2"+mImageUri);
        //将uri加入到额外数据
        intent.putExtra(MediaStore.EXTRA_OUTPUT, mImageUri);
        //启动相机并要求返回结果
        startActivityForResult(intent, TAKE_PICTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case TAKE_PICTURE:
                    //将保存在本地的图片取出并缩小后显示在界面上
                    Bitmap cameraBitmap = BitmapFactory.decodeFile(mImagePath);
                    System.out.println("**********************"+mImagePath);
                    Bitmap Bitmap_CAMERA = ImageTools.zoomBitmap(cameraBitmap, cameraBitmap.getWidth() / SCALE, cameraBitmap.getHeight() / SCALE);
                    //由于Bitmap内存占用较大，这里需要回收内存，否则会报out of memory异常
                    cameraBitmap.recycle();

                    //将处理过的图片显示在界面上，并保存到本地
                    imageView.setImageBitmap(Bitmap_CAMERA);
                    String s=String.valueOf(System.currentTimeMillis());
                    imgName = mImageName;
                    break;
                case CHOOSE_PICTURE:
                    ContentResolver resolver = getContentResolver();
                    //照片的原始资源地址
                    Uri originalUri = data.getData();
                    System.out.println("5555555555555555555555555+originalUri:"+originalUri);
                    try {
                        //使用ContentProvider通过URI获取原始图片
                        Bitmap photoBitmap = MediaStore.Images.Media.getBitmap(resolver, originalUri);
                        if (photoBitmap != null) {
                            //为防止原始图片过大导致内存溢出，这里先缩小原图显示，然后释放原始Bitmap占用的内存
                            Bitmap Bitmap_ALBUM = ImageTools.zoomBitmap(photoBitmap, photoBitmap.getWidth() / SCALE, photoBitmap.getHeight() / SCALE);
                            //释放原始图片占用的内存，防止out of memory异常发生
                            photoBitmap.recycle();

                            //将处理过的图片显示在界面上，并保存到本地
                            imageView.setImageBitmap(Bitmap_ALBUM);
                            String s1=String.valueOf(System.currentTimeMillis());
                            ImageTools.savePhotoToSDCard(Bitmap_ALBUM,getFilesDir().getAbsolutePath(), s1);
                            imgName=s1+".png";
                        }
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * 调用系统相机时创建图片文件，文件直接定位到应用程序内部存储器
     */
    private void createImageFile(){
        //设置图片文件名（含后缀），以当前时间的毫秒值为名称
        mImageName = Calendar.getInstance().getTimeInMillis() + ".jpg";

        //创建图片文件--getFilesDir().getAbsolutePath()直接定位到内部存储（/data/data/<package-name>/file文件夹）
        mImageFile = new File(getFilesDir().getAbsolutePath()+"/", mImageName);
        System.out.println("-------+++++++++mImageFile："+mImageFile);

        //将图片的绝对路径设置给mImagePath，后面会用到
        mImagePath = mImageFile.getAbsolutePath();
        System.out.println("**********************mImagePath:"+mImagePath);
        //按设置好的目录层级创建
        mImageFile.getParentFile().mkdirs();
        //不加这句会报Read-only警告。且无法写入SD
        mImageFile.setWritable(true);
    }
}